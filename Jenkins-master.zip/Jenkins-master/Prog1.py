#!/usr/bin/python3
# Source code for summation of two numbers

def summation(data):
    return sum(data)
